import assert from 'node:assert/strict';
import{simulate,algorithms,basic}from'./dist/engine.mjs';
let checks=0;
function execute(id,vs,opts={}){const r=simulate(id,vs,opts);assert(r.frames.length>0);assert(r.frames.length<5000);for(const f of r.frames){assert(f.line>=0&&f.line<r.meta.code.length,id+' code line');for(const n of f.nodes){assert(n.next===null||f.nodes.some(x=>x.id===n.next));}}checks++;return r;}
function read(r){let f=r.frames.at(-1),p=f.head,seen=new Set(),vs=[];while(p&&!seen.has(p)){seen.add(p);let n=f.nodes.find(x=>x.id===p);assert(n&&!n.dead);vs.push(n.value);p=n.next;}return{vs,loop:p,f};}
function expect(id,vs,opts,expected){const r=execute(id,vs,opts);assert.deepEqual(read(r).vs,expected,id);return r;}
for(const mode of['single','double','circular'])for(const vs of[[],[1],[1,2],[1,2,3,4]]){
 for(const id of basic){if(['access','update','deleteAt'].includes(id)&&!vs.length)continue;const index=Math.min(1,vs.length-(id==='insertAt'?0:1));const opts={mode,index,value:9,target:2};let expected=[...vs];if(id==='insertHead')expected.unshift(9);if(id==='insertTail')expected.push(9);if(id==='insertAt')expected.splice(index,0,9);if(id==='deleteHead')expected.shift();if(id==='deleteTail')expected.pop();if(id==='deleteAt')expected.splice(index,1);if(id==='update')expected[index]=9;
  if(id==='clear')expected=[];if(id==='deleteValue'&&expected.includes(2))expected.splice(expected.indexOf(2),1);
  const r=expect(id,vs,opts,expected);const{f,loop}=read(r);if(mode==='circular')assert.equal(loop,expected.length?f.head:null);else assert.equal(loop,null);
  if(mode==='double'){let p=f.head,prev=null;while(p){let n=f.nodes.find(x=>x.id===p);assert.equal(n.prev,prev);prev=p;p=n.next;}}
 }
}
for(const vs of[[],[1],[1,2],[1,2,3,4,5]]){
 expect('reverse',vs,{},[...vs].reverse());expect('reverseRecursive',vs,{},[...vs].reverse());
 for(const k of[1,2,3,6]){let expected=[];for(let i=0;i<vs.length;i+=k){let s=vs.slice(i,i+k);expected.push(...(s.length===k?s.reverse():s));}expect('reverseK',vs,{k},expected);}
 for(const k of[0,1,2,8]){let shift=vs.length?k%vs.length:0;let exp=shift?[...vs.slice(-shift),...vs.slice(0,-shift)]:vs;expect('rotate',vs,{k},exp);}
 for(let l=0;l<vs.length;l++)for(let r=l;r<vs.length;r++)expect('reverseBetween',vs,{range:l+','+r},[...vs.slice(0,l),...vs.slice(l,r+1).reverse(),...vs.slice(r+1)]);
 execute('middle',vs);execute('palindrome',vs);execute('dedupeSorted',vs);execute('dedupeUnsorted',vs);execute('intersect',vs);execute('cloneRandom',vs);execute('josephus',vs,{k:3});execute('stack',vs,{value:9});expect('queue',vs,{value:9},[...vs,9].slice(1));
 for(let e=-1;e<vs.length;e++){let c=execute('cycleEntry',vs,{entry:e});assert(typeof c.frames.at(-1).note==='string');}
}
for(const id of['mergeSort','insertionSort'])for(const vs of[[],[5],[3,1,4,1,5,2],[5,4,3,2,1],[1,1,1]])expect(id,vs,{},[...vs].sort((a,b)=>a-b));
expect('dedupeSorted',[1,1,1,2,2,3],{},[1,2,3]);expect('dedupeUnsorted',[3,1,3,2,1],{},[3,1,2]);
expect('partition',[3,1,4,2,5,1],{target:3},[1,2,1,3,4,5]);
expect('merge',[1,3,5],{second:[2,4,6]},[1,2,3,4,5,6]);expect('merge',[],{second:[]},[]);expect('merge',[],{second:[1,2]},[1,2]);
expect('lru',[],{},[99,36,12,24]);expect('josephus',[1,2,3,4,5],{k:3},[4]);
const clone=execute('cloneRandom',[1,2,3]);const cf=clone.frames.at(-1);assert.equal(cf.nodes.length,6);for(const n of cf.nodes.filter(n=>n.row===1)){assert.equal(cf.nodes.find(x=>x.id===n.random).row,1);if(n.next)assert.equal(cf.nodes.find(x=>x.id===n.next).row,1);}
for(const a of algorithms){const vs=(a.preset||'12,24,36,48').split(',').map(Number);const opt={value:30};if(a.param)opt[a.param]=a.default;execute(a.id,vs,opt);}
for(const [id,vs,opt]of[['deleteAt',[],{index:0}],['kth',[1],{k:2}],['reverseBetween',[1,2],{range:'1,9'}],['merge',[2,1],{}],['cycle',[1],{entry:2}]])assert.throws(()=>simulate(id,vs,opt));
console.log(JSON.stringify({status:'passed',scenarios:checks,algorithms:algorithms.length}));
